namespace flutter { namespace testing { 
const char* GetSourcePath() {return "/home/engine/src/";} 
const char* GetFixturesPath() {return "/home/engine/src/out/Impeller/arm64/gen/flutter/fml/assets";} 
const char* GetTestingAssetsPath() {return "/home/engine/src/out/Impeller/arm64/gen/flutter/testing/assets";} 
}}
